#include <iostream>
#include "generationByCubitect/generator.hpp"
#include "generationByCubitect/finders.hpp"


int main() {
    initBiomes();
    LayerStack g = setupGenerator(MC_1_12);
    for (int64_t seed = 2000000000; seed < 3000000000; seed++) {
        applySeed(&g, (int64_t)seed);
        bool hasJungle = false;
        bool hasRoofedForest = false;
        bool hasSavanna = false;

        int size = 60;

        int *map = allocCache(&g.layers[g.layerNum - 1], 256, 256);

        Pos pos=getSpawn(MC_1_12,&g,map,seed);
        genArea(&g.layers[g.layerNum - 1], map, pos.x, pos.z, size, size);


        for (long z = 0; z < size * size; z++) {
            int biome = map[z];
            if(biome == 21 || biome == 22 || biome == 23)hasJungle = true;
            else if (biome == 29)hasRoofedForest = true;
            else if (biome == 35 || biome == 36)hasSavanna = true;
        }

        if (hasJungle && hasRoofedForest && hasSavanna)std::cout << "Found good seed : " << seed << ".\n";
        free(map);
    }
    std::cout << "Done.";
    freeGenerator(g);
    system("pause");
}


